function [fmin]=cuckoo_search_sf03(F_index,Num,max_it,D,Xmin,Xmax)
Basize=3;
K = 1;
Ba=ScaleFree(Num,Basize,K);

% Discovery rate of alien eggs/solutions
pa=0.25;

% Random initial solutions
nest = repmat(Xmin, Num, D) + rand(Num, D) .* (repmat((Xmax - Xmin), Num, D));

fitness=zeros(Num,1);
for i=1:Num
    fitness(i,1)=inf;
end

% Get the current best
[fmin,bestnest,nest,fitness]=get_best_nest(nest,nest,fitness,F_index);

%% Starting iterations
for it=1:max_it
    % Generate new solutions (but keep the current best)
    [nest,fitness] = Poprank(nest,fitness);
    new_nest=get_cuckoos(nest,bestnest,Xmin,Xmax,D,Ba);
    [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,F_index);
    
    % Discovery and randomization
    new_nest=empty_nests(nest,Xmin,Xmax,D,pa) ;
    
    % Evaluate this set of solutions
    [fnew,best,nest,fitness]=get_best_nest(nest,new_nest,fitness,F_index);
    
    % Find the best objective so far
    if fnew<fmin
        fmin=fnew;
        bestnest=best;
    end
end %% End of iterations
end

%% --------------- All subfunctions are list below ------------------
%% Get cuckoos by ramdom walk
function nest=get_cuckoos(nest,best,Xmin,Xmax,D,Ba)
% Levy flights
n=size(nest,1);
% Levy exponent and coefficient
% For details, see equation (2.21), Page 16 (chapter 2) of the book
% X. S. Yang, Nature-Inspired Metaheuristic Algorithms, 2nd Edition, Luniver Press, (2010).
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);

for j=1:n
    K = ceil(rand(1)*Ba(j).D);
    k = Ba(j).Sec(K);
    knest=nest(k,:);
    
    s=nest(j,:);
    % This is a simple way of implementing Levy flights
    % For standard random walks, use step=1;
    %% Levy flights by Mantegna's algorithm
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);
    
    % In the next equation, the difference factor (s-best) means that
    % when the solution is the best solution, it remains unchanged.
    stepsize=0.01*step.*(s-knest);
    % Here the factor 0.01 comes from the fact that L/100 should the typical
    % step size of walks/flights where L is the typical lenghtscale;
    % otherwise, Levy flights may become too aggresive/efficient,
    % which makes new solutions (even) jump out side of the design domain
    % (and thus wasting evaluations).
    % Now the actual random walks or flights
    s=s+stepsize.*randn(size(s));
    % Apply simple bounds/limits
    nest(j,:)=boundConstraint(s,D,Xmin,Xmax);
end
end

%% Find the current best nest
function [fmin,best,nest,fitness]=get_best_nest(nest,newnest,fitness,F_index)
% Evaluating all new solutions
for j=1:size(nest,1)
    fnew=cec17_func(newnest(j,:)', F_index);
    if fnew<=fitness(j)
        fitness(j)=fnew;
        nest(j,:)=newnest(j,:);
    end
end
% Find the current best
[fmin,K]=min(fitness) ;
best=nest(K,:);
end

%% Replace some nests by constructing new solutions/nests
function new_nest=empty_nests(nest,Xmin,Xmax,D,pa)
% A fraction of worse nests are discovered with a probability pa
n=size(nest,1);
% Discovered or not -- a status vector
K=rand(size(nest))>pa;
% In the real world, if a cuckoo's egg is very similar to a host's eggs, then
% this cuckoo's egg is less likely to be discovered, thus the fitness should
% be related to the difference in solutions.  Therefore, it is a good idea
% to do a random walk in a biased way with some random step sizes.
%% New solution by biased/selective random walks
stepsize=rand*(nest(randperm(n),:)-nest(randperm(n),:));
new_nest=nest+stepsize.*K;
for j=1:size(new_nest,1)
    s=new_nest(j,:);
  new_nest(j,:)=boundConstraint(s,D,Xmin,Xmax);
end
end


%% You can replace the following by your own functions
function Ba=ScaleFree(N,M,K)
for i = 1 : N
    Ba( i ).D = 0;
    Ba( i ).Num = i;
end

for i = 1 : M
    Ba( i ).Sec = [ 1 : i - 1 , i + 1 : M ];
    Ba( i ).D = M - 1;
end

T = M * ( M - 1 );

for i = M : N - 1
    BaT = Ba;
    TT = T;
    for j = 1 : K
        for num = 1 : length(BaT)
            P( num ) = BaT( num ).D / TT;
        end
        r = rand;
        s = 0;
        for num = 1 : i
            s = s + P( num );
            if r < s
                break;
            end
        end
        TT = TT - BaT( num ).D;
        Number = BaT(num).Num;
        BaT(num) = [];
        Ba( Number ).Sec = [ Ba( Number ).Sec,i + 1 ];
        Ba( Number ).D = Ba( Number ).D + 1;
        Ba( i + 1 ).Sec = [ Ba( i + 1 ).Sec,Number ];
        Ba( i + 1 ).D = Ba( i + 1 ).D + 1;
        T = T + 2;
    end
end

for i=1:N
    for j=1:length(Ba(i).Sec)-1
        for m=j+1:length(Ba(i).Sec)
            if Ba(i).Sec(j)==Ba(i).Sec(m)
                disp('error');
            end
        end
    end
end
end

function [Newpop,Newfitness]=Poprank(pop,fitness)

[b,idx]=sort([fitness]);
Newpop = pop(idx,:);
Newfitness = fitness(idx);
end



clc
clear
tic

N=50;
max_it=1000;
time=30;

D=30;
Xmin=-100;
Xmax=100;

F_index=1:30;
L=length(F_index);
FbestChart_CuckooSearch_M01=zeros(L,time);
FbestChart_CuckooSearch_M02=zeros(L,time);
% FbestChart_CuckooSearch_M03=zeros(L,time);
% FbestChart_CuckooSearch_M04=zeros(L,time);
% FbestChart_CuckooSearch_M05=zeros(L,time);
% FbestChart_CuckooSearch_M06=zeros(L,time);
% FbestChart_CuckooSearch_M07=zeros(L,time);
% FbestChart_CuckooSearch_M08=zeros(L,time);
% FbestChart_CuckooSearch_M09=zeros(L,time);
% FbestChart_CuckooSearch_M10=zeros(L,time);

for l=1:L
    for t=1:time
        
        disp(['F_index = ' num2str(l) '  Time = ' num2str(t)]);
        
        [Fbest01]=cuckoo_search_sf01(F_index(l),N,max_it,D,Xmin,Xmax);
        FbestChart_CuckooSearch_M01(l,t)=Fbest01;
        disp(['CuckooSearch_M01  end.']);
        
        [Fbest02]=cuckoo_search_sf02(F_index(l),N,max_it,D,Xmin,Xmax);
        FbestChart_CuckooSearch_M02(l,t)=Fbest02;
        disp(['CuckooSearch_M02  end.']);
        
%         [Fbest03]=cuckoo_search_sf03(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M03(l,t)=Fbest03;
%         disp(['CuckooSearch_M03  end.']);
%         
%         [Fbest04]=cuckoo_search_sf04(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M04(l,t)=Fbest04;
%         disp(['CuckooSearch_M04  end.']);
%         
%         [Fbest05]=cuckoo_search_sf05(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M05(l,t)=Fbest05;
%         disp(['CuckooSearch_M05  end.']);
%         
%         [Fbest06]=cuckoo_search_sf06(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M06(l,t)=Fbest06;
%         disp(['CuckooSearch_M06  end.']);
%         
%         [Fbest07]=cuckoo_search_sf07(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M07(l,t)=Fbest07;
%         disp(['CuckooSearch_M07  end.']);
%         
%         [Fbest08]=cuckoo_search_sf08(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M08(l,t)=Fbest08;
%         disp(['CuckooSearch_M08  end.']);
%         
%         [Fbest09]=cuckoo_search_sf09(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M09(l,t)=Fbest09;
%         disp(['CuckooSearch_M09  end.']);
%         
%         [Fbest10]=cuckoo_search_sf10(F_index(l),N,max_it,D,Xmin,Xmax);
%         FbestChart_CuckooSearch_M10(l,t)=Fbest10;
%         disp(['CuckooSearch_M10  end.']);
        
    end

end

toc;

save FbestChart_CuckooSearch_M01 FbestChart_CuckooSearch_M01;
save FbestChart_CuckooSearch_M02 FbestChart_CuckooSearch_M02;
% save FbestChart_CuckooSearch_M03 FbestChart_CuckooSearch_M03;
% save FbestChart_CuckooSearch_M04 FbestChart_CuckooSearch_M04;
% save FbestChart_CuckooSearch_M05 FbestChart_CuckooSearch_M05;
% save FbestChart_CuckooSearch_M06 FbestChart_CuckooSearch_M06;
% save FbestChart_CuckooSearch_M07 FbestChart_CuckooSearch_M07;
% save FbestChart_CuckooSearch_M08 FbestChart_CuckooSearch_M08;
% save FbestChart_CuckooSearch_M09 FbestChart_CuckooSearch_M09;
% save FbestChart_CuckooSearch_M10 FbestChart_CuckooSearch_M10;


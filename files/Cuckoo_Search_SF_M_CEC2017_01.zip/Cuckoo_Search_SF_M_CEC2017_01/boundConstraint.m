function X = boundConstraint (X,D,Xmin,Xmax)

% if the boundary constraint is violated, set the value to be the middle
% of the previous value and the bound
%
% Version: 1.1   Date: 11/20/2007
% Written by Jingqiao Zhang, jingqiao@gmail.com

[M,N] = size(X);  
for i = 1:M
        for j = 1:N
            if X(i,j) > Xmax | X(i,j) < Xmin
                X=repmat(Xmin, 1, D) + rand(1, D) .* (repmat((Xmax - Xmin), 1, D));
                break;
            end
        end
end 

end